from fastapi import FastAPI
from fastapi_utils.tasks import repeat_every
import datetime
from poll import run_sentiment_poll, get_latest_results

app = FastAPI()

@app.on_event("startup")
@repeat_every(seconds=1740)  # every 29 minutes
def scheduled_sentiment_poll():
    now = datetime.datetime.now()
    if now.weekday() < 5:  # Monday to Friday only
        print("Running sentiment poll...")
        run_sentiment_poll()

@app.get("/")
def read_root():
    return {"message": "Forex Sentiment Polling API"}

@app.get("/results")
def get_results():
    return get_latest_results()