import datetime

latest_results = {}

def fetch_articles_for_topic(topic):
    # Simulated article content
    return [
        f"{topic} expected to rise soon",
        f"{topic} might fall according to analysts",
        f"Mixed opinions on {topic}",
        f"Rise in {topic} likely due to economic data",
        f"Fall expected in {topic} next week"
    ]

def analyze_sentiment(article):
    rise_keywords = ["rise", "increase", "bullish", "up", "surge", "gain"]
    fall_keywords = ["fall", "decrease", "bearish", "down", "drop", "decline"]
    article_lower = article.lower()
    if any(word in article_lower for word in rise_keywords):
        return "rise"
    elif any(word in article_lower for word in fall_keywords):
        return "fall"
    return "neutral"

def run_sentiment_poll():
    global latest_results
    topics = ["GBP/USD", "USD", "GBP"]
    results = {}
    for topic in topics:
        articles = fetch_articles_for_topic(topic)
        rise, fall = 0, 0
        seen = set()
        for article in articles:
            if article in seen:
                continue
            seen.add(article)
            sentiment = analyze_sentiment(article)
            if sentiment == "rise":
                rise += 1
            elif sentiment == "fall":
                fall += 1
        results[topic] = {"rise": rise, "fall": fall}
        print(f"{topic} | Rise: {rise}, Fall: {fall}")
    latest_results = results

def get_latest_results():
    return latest_results